import React from "react";
import {
  ChevronDown,
} from "lucide-react";
import { useNavigate, Link } from "react-router-dom";
import { useAuth } from "../areausuario/AuthContext";

export default function TopBar({ nome = "Fulano", botoes, navlinks, children }) {
  const { logout } = useAuth();
  const navigate = useNavigate();

  function handleLogout() {
    try {
      logout();
    } finally {
      navigate("/", { replace: true });
    }
  }

  return (
    <header className="topbar">
      <div className="logo">
        <a onClick={() => navigate("/")}>
          Estuda<span>ENEM</span>
        </a>
      </div>
      {botoes && <div className="dash-navbar__buttons">{botoes}</div>}
      {navlinks && <div className="dash-navbar__links">{navlinks}</div>}
      {children}

      <div className="center-link">
        <nav className="center-link">
          <Link to="/simulados">Simulados</Link>
          <Link to="/questoes">Questões</Link>
          <Link to="/sobrenos">Sobre nós</Link>
        </nav>
      </div>

      <div className="dash-navbar__actions">
        <Link to="/areausuario" className="dash-user-btn">
          Olá, {nome}
          <ChevronDown size={16} />
        </Link>
      </div>

      <button className="dash-logout" onClick={handleLogout} aria-label="Sair">
        Sair
      </button>
    </header>
  );
}

export default function TopBarLogado({ nome = "Fulano", botoes, navlinks, children }) {
  botoes += botaoLogin;

  return (
    <TopBar botoes={botoes}></TopBar>
  );
}

TopBarLogado